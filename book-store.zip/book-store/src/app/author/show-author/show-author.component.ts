import { Component ,inject, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { Author } from '../../books/model/book';
import { AuthorServiceService } from '../service/author-service.service';
import {Subscription} from "rxjs";
import { NgIf } from '@angular/common';
@Component({
  selector: 'app-show-author',
  standalone: true,
  imports: [NgIf],
  templateUrl: './show-author.component.html',
  styleUrl: './show-author.component.css'
})
export class ShowAuthorComponent implements OnInit, OnDestroy{
  authorSe!: Author | null;
  private subscription!: Subscription;
  private route: ActivatedRoute = inject(ActivatedRoute);
  private authorG: AuthorServiceService = inject(AuthorServiceService);
  fN!:string|null;
  sN!:string|null;
  id!:number|null;
  ngOnInit(): void {
    this.route.params.subscribe(params => {
    const id = params['id'];
    this.subscription = this.authorG.getAuthorForId(id).subscribe({
      next: (author: Author) => {
         this.authorSe= author;
         this.id=author.id;
         this.fN=author.firstName;
         this.sN=author.lastName;
      },
      error: (_: any) => {
         this.authorSe = null;
      }
      });
      });
      }
  ngOnDestroy(): void {
  this.subscription.unsubscribe();
  }
}
