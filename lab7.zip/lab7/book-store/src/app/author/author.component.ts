import { Component } from '@angular/core';
import { ShowAuthorComponent } from "./show-author/show-author.component";
import { NgIf } from '@angular/common';
import { Router,ActivatedRoute,RouterOutlet } from '@angular/router';
import { inject } from '@angular/core';
@Component({
  selector: 'app-author',
  standalone: true,
  imports: [ShowAuthorComponent,NgIf,RouterOutlet],
  templateUrl: './author.component.html',
  styleUrl: './author.component.css'
})
export class AuthorComponent {
  private router: Router = inject(Router);
  private route: ActivatedRoute = inject(ActivatedRoute);

   show(id:string){
    this.router.navigate(['./', id], {relativeTo: this.route}).then(() => {});
   }
}
