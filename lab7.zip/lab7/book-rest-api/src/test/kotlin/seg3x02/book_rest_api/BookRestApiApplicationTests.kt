package seg3x02.book_rest_api

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class BookRestApiApplicationTests {

	@Test
	fun contextLoads() {
	}

}
