package seg3x02.book_rest_api.assemblers

import org.springframework.hateoas.CollectionModel
import org.springframework.stereotype.Component
import org.springframework.hateoas.server.mvc.RepresentationModelAssemblerSupport
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder
import seg3x02.book_rest_api.entities.Author
import seg3x02.book_rest_api.controller.ApiController
import seg3x02.book_rest_api.representation.AuthorNameRepresentation





@Component
class AuthorModelAssembler:RepresentationModelAssemblerSupport<Author,
AuthorNameRepresentation>(ApiController::class.java, AuthorNameRepresentation::class.java){
    override fun toModel(entity: Author): AuthorNameRepresentation {
        val autR=instantiateModel(entity)
        autR.id=entity.id
        autR.firstName=entity.firstName
        autR.lastName=entity.lastName
        autR.books= entity.books
        autR.add(WebMvcLinkBuilder.linkTo(
            WebMvcLinkBuilder.methodOn(ApiController::class.java)
                .getBioById(entity.id))
            .withRel("bio"))
        return autR
    }
    override fun toCollectionModel(entities: Iterable<Author>): CollectionModel<AuthorNameRepresentation> {
        val authorD = super.toCollectionModel(entities)
        authorD.add(WebMvcLinkBuilder.linkTo(
            WebMvcLinkBuilder.methodOn(
                ApiController::class.java).allBooks()).withSelfRel())
        return authorD
    }



}