package seg3x02.book_rest_api.assemblers

import org.springframework.hateoas.server.mvc.RepresentationModelAssemblerSupport
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder
import org.springframework.stereotype.Component
import seg3x02.book_rest_api.controller.ApiController
import seg3x02.book_rest_api.entities.Bio
import seg3x02.book_rest_api.representation.BioRepresentation

@Component
class BioModelAssembler: RepresentationModelAssemblerSupport<Bio,
        BioRepresentation>(ApiController::class.java, BioRepresentation::class.java) {
    override fun toModel(entity: Bio): BioRepresentation {
        var bioR=instantiateModel(entity)
        bioR.add(
            WebMvcLinkBuilder.linkTo(
            WebMvcLinkBuilder.methodOn(ApiController::class.java)
                .getBookById(entity.id))
            .withSelfRel())
        bioR.biodata=entity.biodata
        return bioR
    }
}