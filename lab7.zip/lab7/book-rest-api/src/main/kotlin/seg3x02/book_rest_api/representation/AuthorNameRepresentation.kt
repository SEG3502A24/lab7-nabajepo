package seg3x02.book_rest_api.representation
import com.fasterxml.jackson.annotation.JsonInclude
import org.springframework.hateoas.RepresentationModel
import org.springframework.hateoas.server.core.Relation
import seg3x02.book_rest_api.entities.Bio
import seg3x02.book_rest_api.entities.Book
@Relation(collectionRelation = "authors")
@JsonInclude(JsonInclude.Include.NON_NULL)
class AuthorNameRepresentation:RepresentationModel<AuthorNameRepresentation>(){
    var id: Long = 0
    var firstName: String = ""
    var lastName: String = ""
    var books: MutableList<Book> = ArrayList()
    var bio: Bio = Bio()

}