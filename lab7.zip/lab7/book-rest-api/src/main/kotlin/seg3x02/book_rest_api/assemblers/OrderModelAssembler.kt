package seg3x02.book_rest_api.assemblers

import org.springframework.hateoas.CollectionModel
import org.springframework.stereotype.Component
import org.springframework.hateoas.server.mvc.RepresentationModelAssemblerSupport
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder
import seg3x02.book_rest_api.entities.Order
import seg3x02.book_rest_api.controller.ApiController
import seg3x02.book_rest_api.entities.Book
import seg3x02.book_rest_api.representation.BookRepresentation
import seg3x02.book_rest_api.representation.OrderRepresentation

@Component
class OrderModelAssembler: RepresentationModelAssemblerSupport<Order,
        OrderRepresentation>(ApiController::class.java, OrderRepresentation::class.java){
    override fun toModel(entity: Order): OrderRepresentation {
        val orderReprs=instantiateModel(entity)
        orderReprs.add(WebMvcLinkBuilder.linkTo(
            WebMvcLinkBuilder.methodOn(ApiController::class.java)
                .getBookById(entity.id))
            .withSelfRel())
        orderReprs.id=entity.id
        orderReprs.quantity=entity.quantity
        return orderReprs
    }
    override fun toCollectionModel(entities: Iterable<Order>): CollectionModel<OrderRepresentation> {
        val orderT = super.toCollectionModel(entities)
        orderT.add(WebMvcLinkBuilder.linkTo(
            WebMvcLinkBuilder.methodOn(
                ApiController::class.java).allBooks()).withSelfRel())
        return orderT
    }
}